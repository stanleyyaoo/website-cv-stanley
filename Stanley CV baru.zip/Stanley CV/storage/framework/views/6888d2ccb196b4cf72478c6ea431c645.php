<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- My CSS -->
    <link rel="stylesheet" href="style.css" />

    <title>Stanley Yao</title>
  </head>
  <body id="home">
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Stanley Yao</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#profile">Profil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#skill">Skill</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- akhir navbar -->

    <!-- Jumbotron -->
    <section class="jumbotron text-center">
      <img src="cen hao.jpeg" alt="Qin Shi Huang" width="200" class="rounded-circle img-thumbnail" />
      <h1 class="display-4">Stanley Yao</h1>
      <p class="lead">Stanley Yao | Penggangguran</p>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#fff"
          fill-opacity="10"
          d="M0,224L30,197.3C60,171,120,117,180,112C240,107,300,149,360,170.7C420,192,480,192,540,160C600,128,660,64,720,58.7C780,53,840,107,900,117.3C960,128,1020,96,1080,74.7C1140,53,1200,43,1260,58.7C1320,75,1380,117,1410,138.7L1440,160L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"
        ></path>
      </svg>
    </section>

    <!-- akhir jumbotron -->

    <!-- About -->
    <section id="profile">
      <div class="conteiner">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>Profil</h2>
          </div>
          s
        </div>
        <div class="row justify-content-center fs-5 text-center">
          <div class="col-md-4">
            <p>
              Perkenalkan, Nama saya Stanley. Biasa dipanggil Stan, saya merupakan mahasiswa dari Universitas Internasional Batam dan berumur 19 tahun. saya mengambil program studi Sistem Informasi dan sedang manjalani semester ke
            </p>
          
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#e2edff"
          fill-opacity="1"
          d="M0,160L30,165.3C60,171,120,181,180,160C240,139,300,85,360,101.3C420,117,480,203,540,229.3C600,256,660,224,720,224C780,224,840,256,900,250.7C960,245,1020,203,1080,170.7C1140,139,1200,117,1260,128C1320,139,1380,181,1410,202.7L1440,224L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"
        ></path>
      </svg>
    </section>
    <!-- akhir about -->

    <!--skill-->
    
    <div style = "display: flex; justify-content: center;padding-top: 50px;" id = "skill">
      
    <div class="language" style = "width: 80%;">
      <p style = "margin-bottom: 30px;">Language</p>

      <p>English</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 70%"></div>
      </div>
      <p>Indonesian</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 100%"></div>
      </div>
    </div>
  </div>

   
  <div style = "display: flex; justify-content: center; margin-top: 100px;">
      
    <div class="skill" style = "width: 80%;">
      <p style = "margin-bottom: 30px;">Personal Skill</p>

      <p>Communication</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 75%"></div>
      </div>
      <p>Leadership</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 40%"></div>
      </div>
      <p>Organisation</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 80%"></div>
      </div>
      <p>Teamwork</p>
      <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
        <div class="progress-bar" style="width: 80%"></div>
      </div>
    </div>
  </div>
     <!--akhir skill-->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>


</section>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>

<?php /**PATH C:\Users\user\OneDrive\AssistantComputerControl\OneDrive\Desktop\Stanley CV\resources\views/welcome.blade.php ENDPATH**/ ?>